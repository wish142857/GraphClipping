计算机图形学
多边形裁剪 实验报告
===
* **姓名：黄 翔**
* **班级：软件 71**
* **学号：2017013570**
---

[toc]

### 1. 实验概述

#### 1.1 实验内容
* 本次实验实现了**基于*Weiler-Atherton*算法的多边形裁剪程序**。
    * 程序支持凹、凸、带一个或多个内环的多边形
    * 程序具有图形界面，并具有完善的消息提示框
    * 程序具有较强的鲁棒性，能对用户的输入进行合法性检测
    * 程序代码均为原创，并具有较为详细的注释

#### 1.2 开发环境
* **操作系统**：`Windows 10`
* **编程语言**：`C++`
* **GUI 框架**：`Qt 5`

#### 1.3 仓库地址
* [Github - GraphClipping](https://github.com/wish142857/GraphClipping)

#### 1.4 文件描述
| 文件 | 描述  |
|  :----:  | :----:  |
| `algorithm.h`/`algorithm.cpp`  | 包含程序算法的实现 |
| `define.h`  | 包含常量、枚举、结构的定义 |
| `main.cpp`  | 包含程序入口函数，创建并显示`Qt`窗口 |
| `window.h`/`window.cpp` | 包含程序主窗口类的定义，及主要逻辑的实现 |

### 2. 实现原理

#### 2.1 数据结构

##### 2.1.1 `Point` 顶点
``` C++
struct Point {
    // *** 变量 ***
    int x;      // X 横坐标
    int y;      // Y 纵坐标
    // *** 构造函数 ***
    Point() : x(0), y(0) {}
    Point(int x, int y) : x(x), y(y) { }
    // *** 运算符重载 ***
    bool operator ==(const Point& p) { return this->x == p.x && this->y == p.y; }
};
```
`Point`结构用于表示顶点，由于点击及绘制时的精度有限，顶点横纵坐标数值均以整型记录，节省了程序空间开销。

##### 2.1.2 `CPoint` 交点
``` C++
struct CPoint {
    // *** 变量 ***
    double x;       // X 横坐标
    double y;       // Y 纵坐标
    double t;       // t 参数 [0,1]
    CPoint *link;   // 顶点对应副本交点指针 nullptr: 非首位节点
    CPoint *other;  // 交点对应副本交点指针 nullptr: 非交点
    CPoint *next;   // 列表下一元素指针
    bool isEntry;   // True: 入点  False: 出点
    bool isVisited; // True: 已追踪  False: 未追踪
    // *** 构造函数 ***
    CPoint() : x(0), y(0), t(0), link(nullptr), other(nullptr), next(nullptr), isEntry(false), isVisited(false) { }
    CPoint(double x, double y, double t = 0, CPoint *l = nullptr, CPoint *o = nullptr, CPoint *n = nullptr, bool e = false, bool v = false)
        : x(x), y(y), t(t), link(l), other(o), next(n), isEntry(e), isVisited(v) { }
};
```
`CPoint`结构用于表示交点（及算法中等同交点的顶点）。除了点的横纵坐标及在线段上的`t`参数，`CPoint`还记录了当前交点的一些属性，例如为入点还是为出点、是否已追踪。同时，为了后续算法中构建链表，结构还包含一些指针变量。

##### 2.1.3 `Line` 线段
``` C++
struct Line {
    // *** 变量 ***
    Point begin;            // 起点
    Point end;              // 终点
    CPoint *cpointList;     // 交点列表
    bool isEndLine;         // 是否为环的终边
    // *** 构造函数 ***
    Line() : begin(Point()), end(Point()), cpointList(nullptr), isEndLine(false)  { }
    Line(Point begin, Point end) : begin(begin), end(end), cpointList(nullptr), isEndLine(false) { }
    // *** 析构函数 ***
    ~Line() { CPoint *q = nullptr, *p = cpointList; while (p) { q = p; p = p->next; delete q; } }
    // *** 插入交点 ***
    void insertCPoint(CPoint *cpoint) {
        if (cpoint) {
            CPoint *q = nullptr, *p = cpointList;
            while (p && cpoint->t > p->t) { q = p; p = p->next; }
            if (q) { q->next = cpoint; cpoint->next = p; }
            else { cpointList = cpoint; cpoint->next = p; }
        }
    }
};
```
`Line`结构用于表示线段。其中，包含线段上交点的链表及一些其他属性。线段上的交点按照据线段起始点的距离升序排列。

##### 2.1.4 `Polygon` 多边形（无内环）
``` C++
typedef  std::vector<Point> Polygon;
```
`Polygon`结构用于表示无内环的多边形，由多边形的顶点列表指示。

##### 2.1.5 `Polygons` 多边形（带内环）
``` C++
typedef  std::vector<std::vector<Point>> Polygons;
```
`Polygons`结构用于表示带内环的多边形，由多个无内环的多边形（单个环）的顶点列表指示。其中，`Polygons[0]`记录外环，其余元素记录内环。

#### 2.2 主要算法

##### 2.2.1 判断多边形（无内环）顶点是否顺时针序
``` C++
// [算法] 判断多边形（无内环）顶点是否顺时针序
bool checkPolygonClockWise(const Polygon &polygon);
```
**实现原理**：对于多边形每条边，计算原点到边两点构成的两个向量的叉乘。将所有边的所有计算结果相加，若此值为正，则顶点为顺时针序排列；否则，顶点为逆时针序排列。

##### 2.2.2 判断点是否在多边形（无内环）内部
``` C++
bool checkPointInPolygon(const Point &point, const Polygon &polygon);
```
**实现原理**：过点引一条平行于 X 轴的直线，计算直线与多边形的交点数量。若点左侧交点及右侧交点均为奇数，则点在多边形内部。


##### 2.2.3 判断两条线段是否规范相交
``` C++
bool checkLineWithLine(const Line &lineA, const Line &lineB);
```
**实现原理**：规范相交即具有非顶点的交点。通过由线段构造向量并进行叉乘运算即可判断。

##### 2.2.4 判断多边形（无内环）对于多边形（带内环）是否有效
``` C++
bool checkPolygonWithPolygons(const Polygon &polygon, const Polygons &polygons);
```
**实现原理**：若多边形`A`的边与多边形`B`的边无交，且`A`所有顶点在`B`外环外，或`A`所有顶点在`B`内环内，则`A`、`B`显然无交，`A` 对于 `B` 无效，在计算裁剪区域时可忽视 A。检测时，调用`checkPointInPolygon()`检测任意单个顶点即可。在边无交的情况下，任意顶点在外环外，则所有顶点在外环外；任意顶点在内环内，则所有顶点在内环内。

##### 2.2.5 判断两条线段是否有交点
``` C++
bool checkCrossPoint(const Line &lineA, const Line &lineB);
```
**实现原理**：类似 `checkLineWithLine()`，不同的是此函数容许顶点为交点。

##### 2.2.6 计算两条线段的交点
``` C++
CPoint* calculateCrossPoint(const Line &lineA, const Line &lineB);
```
**实现原理**：利用参数法联立方程即可计算出交点坐标及其相对于两条线段的`t`参数。其中，还需判断交点为入点还是出点，可通过与法线求点积判断符号以判断。对于外环（逆时针）, 线段向量`(x, y)`, 则`(-y, x)`恰为其外法向量（界面坐标系下），对于内环（顺时针）, 线段向量`(x, y)`, 则`(-y, x)`恰为其内法向量（界面坐标系下）。将主多边形线段与裁剪多边形线段外/内法向量做点积，若结果为负，交点为入点; 若结果为正，交点为出点。

##### 2.2.7 进行多边形（带内环）裁剪
``` C++
int startClipPolygon(Polygons &polygonsA, Polygons &polygonsB, Polygons &polygonsC);
```
**实现原理**：*Weiler-Atherton* 算法。具体实现流程如下（假设主多边形顶点数为`m`，裁剪多边形顶点数为`n`）：
1. **【初始化】`O(1)`** ：清空结果列表；
2. **【创建边列表】`O(m+n)`** ：分别将主多边形、裁剪多边形的外环以逆时针、内环以顺时针构成边建立边列表；
3. **【求取边交点】`O(mn)`** ：将主多边形、裁剪多边形两两联立，计算边交点，插入边的`Line.cpointList`属性；
4. **【创建点列表】`O(m+n)`** ：遍历边列表，建立顶点/交点列表；
5. **【执行裁剪算法】`O(m+n)`** ：按照 *Weiler-Atherton* 算法追踪点列表中的点，并加入结果列表；
6. **【返回裁剪结果】`O(m+n)`** ：进行内存释放，返回裁剪结果。

### 3. 使用说明
#### 3.1 界面说明
程序的图形界面如下：
![avatar](/pic/GUI.png)

**其中，<font color=#d81e06> A（红色）</font>指代主多边形，<font color=#1296db> B（蓝色）</font>指代裁剪多边形，<font color=#ffd700> C（黄色）</font>指代裁剪结果。**

#### 3.2 操作说明
* **【选定绘制图形】** 在开始绘制前，你需要点击`A`（主多边形）或`B`（裁剪多边形）的**开始裁剪**按钮以选定绘制的图形。当绘制图形被选中时，对应的`A`、`B`图标将被点亮，如下图：
![avatar](/pic/A.png)  ![avatar](/pic/B.png)

* **【绘制图形】** 选定绘制图形后，在右侧绘图区域点击**鼠标左键**画点，点击**鼠标右键**闭合。程序将自动检测所绘制多边形的合法性，若下一步操作将造成多边形不合法，操作将自动中断，左上角提示框将有相应提示：
    1. 对于主多边形或裁剪多边形，不可以造成线段交叉。
    2. 在绘制带内环的多边形时，你需先绘制外环，再绘制内环。内环顶点不可以在外环之外，也不可以在其他内环之内。
    3. 不可以出现内环中有内环的情况。
* **【撤销与清除】** 点击**撤销**按钮即可撤销上一步的绘制操作；点击**清除**按钮即可清空绘制图形。
* **【开始裁剪】** 当主多边形及裁剪多边形均绘制完毕，且合法，点击**开始裁剪**按钮即可进行裁剪。裁剪结果将在绘图区中以<font color=#ffd700>黄色</font>标出。当图标由 **×** 变为 **√**，图形即合法，如下：
![avatar](/pic/N.png)  ![avatar](/pic/P.png)
